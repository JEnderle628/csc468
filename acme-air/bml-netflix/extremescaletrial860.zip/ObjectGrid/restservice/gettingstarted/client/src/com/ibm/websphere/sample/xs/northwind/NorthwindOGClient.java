//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind;

import com.ibm.websphere.objectgrid.ClientClusterContext;
import com.ibm.websphere.objectgrid.ObjectGrid;
import com.ibm.websphere.objectgrid.ObjectGridManagerFactory;
import com.ibm.websphere.objectgrid.ObjectGridRuntimeException;
import com.ibm.websphere.objectgrid.Session;
import com.ibm.websphere.objectgrid.security.config.ClientSecurityConfiguration;
import com.ibm.websphere.objectgrid.security.config.ClientSecurityConfigurationFactory;
import com.ibm.websphere.objectgrid.security.plugins.CredentialGenerator;
import com.ibm.websphere.objectgrid.security.plugins.builtins.UserPasswordCredentialGenerator;
import com.ibm.websphere.sample.xs.northwind.NorthwindDataAccess;

/**
 * This simple ObjectGrid client that connects to a remote ObjectGrid
 * and allows persisting and querying entities in a partitioned grid.<p>
 *
 * For details on how to run this program see the GETTINGSTARTED_README.txt
 * file or the ECLIPSE_README.txt included with this sample.
 */
public class NorthwindOGClient {
    
    private static final String REST_SECURITY_PROPS_FILE = "rest.sample.security.props";
    private static final String REST_SECURITY_CREDENTIALS = "rest.sample.security.credentials";
    
    /**
     * Connect to a remote ObjectGrid
     * @param cep the catalog server end points in the form: <host>:<port>
     * @param gridName the name of the ObjectGrid to connect to that is managed by the Catalog Service
     * @return a client ObjectGrid connection.
     */
    static public ObjectGrid connectClient(String cep, String gridName) {
        try {

            ClientClusterContext ccc = null;
            String securityProps = System.getProperty(REST_SECURITY_PROPS_FILE);
            String securityCredentials = System.getProperty(REST_SECURITY_CREDENTIALS);
            if (securityProps == null) {
                // Connect to the Catalog Server. The security and client
                // override XML are not specified.
                ccc = ObjectGridManagerFactory.getObjectGridManager().connect(cep, null, null);
            } else {
                // Connect to the Catalog Server with security.
                if (securityCredentials == null)
                    throw new IllegalArgumentException( REST_SECURITY_CREDENTIALS + " system property is null!");

                // Get user and pass.
                String[] tokens = securityCredentials.split(":");
                if (tokens == null || tokens.length != 2) {
                    throw new IllegalArgumentException(REST_SECURITY_CREDENTIALS + " format is incorrect!");
                }

                // Creates a ClientSecurityConfiguration object using the
                // specified file
                ClientSecurityConfiguration clientSC = ClientSecurityConfigurationFactory
                .getClientSecurityConfiguration(securityProps);
                // Creates a CredentialGenerator using the passed-in user and
                // password.
                CredentialGenerator credGen = new UserPasswordCredentialGenerator(tokens[0], tokens[1]);
                clientSC.setCredentialGenerator(credGen);
                ccc = ObjectGridManagerFactory.getObjectGridManager().connect(cep, clientSC, null);
            }

            // Retrieve the ObjectGrid client connection and return it.
            ObjectGrid grid = ObjectGridManagerFactory.getObjectGridManager().getObjectGrid(ccc, gridName);
            return grid;
        } catch (Exception e) {
            throw new ObjectGridRuntimeException("Unable to connect to catalog server at endpoints:" + cep, e);
        }
    }

    /**
     * The program main.  There are four arguments:<p>
     * [0]    The catalog server end points in the form <host>:<port>
     * [1..n] The ObjectGrid operation to perform and parameters:
     *     load default
     *     load customer <companyCode> <contactName> <companyName> <numOrders> <firstOrderId> <shipCity> <maxItems> <discountPct>
     *     load category <categoryId> <categoryName> <firstProductId> <numProducts>
     *     display customer <companyCode>
     *     display category <categoryId>
     *
     * Examples:
     * java ... load default
     * java ... load customer IBM "John Doe" "IBM Corporation" 5 5000 Rochester 5 0.05
     * java ... load category 5 "Household Items" 100 5
     * java ... display customer IBM
     * java ... display category 5
     *
     * @param args the arguments as previously defined.
     */
    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            printUsage();
            return;
        }

        // Connect to a remote ObjectGrid
        ObjectGrid grid = connectClient(args[0], "NorthwindGrid");
        Session session = grid.getSession();

        System.out.println();
        System.out.println("Connected to the WebSphere eXtreme Scale grid: NorthwindGrid");

        if (args[1].startsWith("l")) {
            // Load
            if (args[2].startsWith("d")) {
                System.out.println("Loading the grid with the default set of Customers and Categories.");
                NorthwindDataAccess.loadGrid(grid);
            } else if (args[2].startsWith("cu")) {
                // Customer
                if (args.length != 11) {
                    printUsage();
                    return;
                }
                System.out.println("Loading the grid with a new Customer and Orders...");
                NorthwindDataAccess.persistCustomerOrders(session, args[3], args[4], args[5], Integer
                        .parseInt(args[6]), Integer.parseInt(args[7]), args[8], Integer.parseInt(args[9]), Float
                        .parseFloat(args[10]));

                System.out.println("Customer and Orders loaded....");
                NorthwindDataAccess.displayCustomer(session, args[3]);


            } else if (args[2].startsWith("ca")) {
                // Category
                if (args.length != 7) {
                    printUsage();
                    return;
                }
                System.out.println("Loading the grid with a new Category and Products...");
                NorthwindDataAccess.persistCategoryProducts(session, Integer.parseInt(args[3]), args[4], Integer
                        .parseInt(args[5]), Integer.parseInt(args[6]));

                System.out.println("Category and Products loaded...");
                NorthwindDataAccess.displayCategory(session, Integer.parseInt(args[3]));

            } else {
                printUsage();
                return;
            }
            System.out.println();
            System.out.println("Operation complete.");

        } else if (args[1].startsWith("d")) {
            // Display
            if(args[2].startsWith("cu")) {
                // Customer
                if (args.length != 4) {
                    printUsage();
                    return;
                }
                System.out.println("Displaying Customer Report for Customer Code: " + args[3]);
                NorthwindDataAccess.displayCustomer(session, args[3]);
                NorthwindDataAccess.displayCustomerOrderReport(session, args[3]);

            } else if (args[2].startsWith("ca")) {
                // Category
                if (args.length != 4) {
                    printUsage();
                    return;
                }
                System.out.println("Displaying Category Report for Category ID: " + args[3]);
                NorthwindDataAccess.displayCategory(session, Integer.parseInt(args[3]));

            } else {
                printUsage();
                return;
            }
            System.out.println();
            System.out.println("Operation complete.");

        } else {
            System.out.println("Unknown operation: " + args[1]);
            printUsage();
        }
    }

    private static void printUsage() {
        System.out.println("This program persists and queries entities in the NorthwindGrid.");
        System.out.println();
        System.out.println("script usage: runclient.sh/runclient.bat <command>");
        System.out.println("java usage: java <jvm args> Client <catalog endpoint hostname:port> <command>");
        System.out.println();
        System.out.println("The following commands are available:");
        System.out.println("  load default");
        System.out.println("  load customer <companyCode> <contactName> <companyName> <numOrders> <firstOrderId> <shipCity> <maxItems> <discountPct>");
        System.out.println("  load category <categoryId> <categoryName> <firstProductId> <numProducts>");
        System.out.println("  display customer <companyCode>");
        System.out.println("  display category <categoryId>");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("... load default");
        System.out.println("... load customer IBM \"John Doe\" \"IBM Corporation\" 5 5000 Rochester 5 0.05");
        System.out.println("... load category 5 \"Household Items\" 100 5");
        System.out.println("... display customer IBM");
        System.out.println("... display category 5");
    }
}
