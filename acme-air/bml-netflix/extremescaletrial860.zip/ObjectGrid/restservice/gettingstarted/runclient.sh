#!/bin/sh

#  This sample program is provided AS IS and may be used, executed, copied and modified
#  without royalty payment by customer
#  (a) for its own instruction and study,
#  (b) in order to develop applications designed to run with an IBM WebSphere product,
#  either for customer's own internal use or for redistribution by customer, as part of such an
#  application, in customer's own products.
#  Licensed Materials - Property of IBM
#  5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009

# Setup our environment variables.
fileDir=`dirname ${0}`
. "$fileDir"/env.sh

if [ ! -z $WXS_INSTALLATION ]
then
# Run the client in a standalone installation
  $JAVA_EXE -classpath "$OG_CLASSPATH:$SAMPLE_CLIENT_CLASSPATH" "$OBJECTGRID_ENDORSED_DIRS" -Djava.util.logging.manager=com.ibm.ws.bootstrap.WsLogManager -Djava.util.logging.configureByServer=true com.ibm.websphere.sample.xs.northwind.NorthwindOGClient $CATALOGSERVER_HOST:$CATALOGSERVER_PORT $@

else 
# Run the client in a WAS installation
  $JAVA_EXE $WAS_LOGGING $CONSOLE_ENCODING "-Dws.ext.dirs=$WAS_EXT_DIRS:$WAS_HOME\plugins:$SAMPLE_CLIENT_CLASSPATH" -Dserver.root="$WAS_HOME" -classpath "$WAS_CLASSPATH" com.ibm.ws.bootstrap.WSLauncher "com.ibm.websphere.sample.xs.northwind.NorthwindOGClient" "$CATALOGSERVER_HOST:$CATALOGSERVER_PORT" $@
fi
