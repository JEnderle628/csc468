#!/bin/sh

#  This sample program is provided AS IS and may be used, executed, copied and modified
#  without royalty payment by customer
#  (a) for its own instruction and study,
#  (b) in order to develop applications designed to run with an IBM WebSphere product,
#  either for customer's own internal use or for redistribution by customer, as part of such an
#  application, in customer's own products.
#  Licensed Materials - Property of IBM
#  5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009, 2010

binDir=`dirname $0`

# The path to the sample
cd "$binDir"
SAMPLE_HOME=`pwd`

# WebSphere Application Server integrated installation or stand-alone installation?
if [ -f "${SAMPLE_HOME}/../../../../bin/setupCmdLine.sh" ]; then
    # WebSphere Application Server install
    cd "${SAMPLE_HOME}/../../../../bin"
    . ./setupCmdLine.sh
    cd "${SAMPLE_HOME}"
    OBJECTGRID_HOME="${SAMPLE_HOME}/../../../.."
else
    # Stand-alone
    WXS_INSTALLATION=WXSA
    OBJECTGRID_HOME="${SAMPLE_HOME}/../.."
fi

# *********************************************************
# ***    As needed, uncomment the following line and    ***
# ***    change JAVA_HOME to match your environment     ***
# *********************************************************
# JAVA_HOME="/opt/java"

# *********************************************************
# *** The following variables do not need to be changed ***
# *********************************************************

# The path to the endorsed directory where the ORB is located.
OBJECTGRID_ENDORSED_DIRS="-Djava.endorsed.dirs=${OBJECTGRID_HOME}/lib/endorsed"

# The ObjectGrid runtime class path.
if [ ! -z "WXS_INSTALLATION" ]
then
    OG_CLASSPATH="${OBJECTGRID_HOME}/properties:${OBJECTGRID_HOME}/lib/objectgrid.jar"
    export OG_CLASSPATH
fi

if [ ! -f "${OBJECTGRID_HOME}/lib/ogclient.jar" -a ! -f "${OBJECTGRID_HOME}/lib/wsogclient.jar" ]
then
    echo Unable to find ObjectGrid libraries.  Set OBJECTGRID_HOME or copy this sample into the ObjectGrid installation directory.
fi

# If JAVA_HOME is not defined above or external to this script.
if [ -z "$JAVA_HOME" ]
then
    JAVA_HOME="${OBJECTGRID_HOME}/../java"
fi

# The path and filename of the Java executable.
if [ -f ${JAVA_HOME}/jre/bin/java ]; then
    JAVA_EXE="${JAVA_HOME}/jre/bin/java"
else
    JAVA_EXE="${JAVA_HOME}/bin/java"
fi

if [ ! -f ${JAVA_EXE} ]; then
    echo "Set the JAVA_HOME environment variable to a valid Java Runtime Environment directory."
    exit
fi

# The classpath for application client class files.
SAMPLE_CLIENT_CLASSPATH="${SAMPLE_HOME}/client/bin:${SAMPLE_HOME}/common/bin:${OBJECTGRID_HOME}/security"

# The classpath for application server class files.
SAMPLE_SERVER_CLASSPATH="${SAMPLE_HOME}/server/bin:${SAMPLE_HOME}/common/bin"

# The location of the catalog server host in which the client will connect.
CATALOGSERVER_HOST="localhost"

# The bootstrap port of the catalog server in which the client will connect.
# The catalog service will choose 2809 by default which can conflict with WebSphere Application Server
CATALOGSERVER_PORT="2909"

# The JMX Port that the Catalog Service will use for Java Management Extensions
# The catalog service will choose 1099 by default which can conflict with WebSphere Application Server Community Edition
CATALOGSERVER_JMX_PORT="1199"

# The endpoints passed to the catalog server when started.
CATALOG_SERVICE_ENDPOINTS="cs0:localhost:6600:6601"

#ObjectGrid security variables
CLUSTER_SECURITY_FILE="${SAMPLE_HOME}/security/security.xml"
SERVER_PROPS="${SAMPLE_HOME}/security/server.props"
JAAS_CONFIG="${SAMPLE_HOME}/security/og_jaas.config"
OG_AUTH_POLICY="${SAMPLE_HOME}/security/og_auth.policy"
CLIENT_SECURITY_PROPS="${SAMPLE_HOME}/security/security.ogclient-java.properties"

export JAVA_HOME OBJECTGRID_HOME OBJECTGRID_ENDORSED_DIRS SAMPLE_CLIENT_CLASSPATH CATALOGSERVER_HOST CATALOGSERVER_PORT CATALOGSERVER_JMX_PORT CATALOG_SERVICE_ENDPOINTS JAVA_EXE CLUSTER_SECURITY_FILE SERVER_PROPS JAAS_CONFIG OG_AUTH_POLICY CLIENT_SECURITY_PROPS
