//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind.entities;

import com.ibm.websphere.projector.annotations.Basic;
import com.ibm.websphere.projector.annotations.CascadeType;
import com.ibm.websphere.projector.annotations.Entity;
import com.ibm.websphere.projector.annotations.Id;
import com.ibm.websphere.projector.annotations.IdClass;
import com.ibm.websphere.projector.annotations.ManyToOne;
import com.ibm.websphere.projector.annotations.Version;

@Entity
@IdClass(OrderDetailId.class)
public class OrderDetail {
    @Id
    @ManyToOne(cascade=CascadeType.PERSIST)
    Order order;

    @Id
    int productId;

    /**
     * The version field is used for optimistic locking by
     * eXtreme Scale and is automatically updated.
     */
    @Version
    private int version;

    @Basic
    int categoryId;

    @Basic
    float discount;

    @Basic
    short quantity;

    @Basic
    double unitPrice;


    public OrderDetail() {
        super();
    }

    public OrderDetail(Order order, int productId, int categoryId) {
        super();
        this.order = order;
        this.productId = productId;
        this.categoryId = categoryId;
    }

    public float getDiscount() {
        return discount;
    }

    public void setDiscount(float discount) {
        this.discount = discount;
    }

    public short getQuantity() {
        return quantity;
    }

    public void setQuantity(short quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    @Override
    public String toString() {
        return "OrderDetail[(orderId=" + order.getOrderId() + ", catId=" + categoryId + ", prodID=" + productId + "), qty=" + quantity + ", unitPrice="
                + unitPrice + ", discount=" + discount + ", ver=" + version + "]";
    }
}
