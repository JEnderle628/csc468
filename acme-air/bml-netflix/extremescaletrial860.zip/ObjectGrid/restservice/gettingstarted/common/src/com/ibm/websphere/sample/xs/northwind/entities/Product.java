//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind.entities;

import com.ibm.websphere.projector.annotations.Basic;
import com.ibm.websphere.projector.annotations.CascadeType;
import com.ibm.websphere.projector.annotations.Entity;
import com.ibm.websphere.projector.annotations.Id;
import com.ibm.websphere.projector.annotations.IdClass;
import com.ibm.websphere.projector.annotations.ManyToOne;
import com.ibm.websphere.projector.annotations.Version;

@Entity
@IdClass(ProductId.class)
public class Product {

	@Id
	int productId;

	@Id
	@ManyToOne(cascade=CascadeType.PERSIST)
    Category category;

    /**
     * The version field is used for optimistic locking by
     * eXtreme Scale and is automatically updated.
     */
    @Version
    private int version;

	@Basic
	String productName;

	@Basic
	Double unitPrice;

	@Basic
	boolean discontinued;

	@Basic
	short unitsInStock;

	public Product() {
		super();
	}

	public Product(int productId, Category category) {
        super();
        this.productId = productId;
        this.category = category;
    }

    public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public Double getUnitPrice() {
		return unitPrice;
	}


	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public boolean isDiscontinued() {
		return discontinued;
	}


	public void setDiscontinued(boolean discontinued) {
		this.discontinued = discontinued;
	}


	public short getUnitsInStock() {
		return unitsInStock;
	}


	public void setUnitsInStock(short unitsInStock) {
		this.unitsInStock = unitsInStock;
	}

	public Category getCategory() {
        return category;
    }


    public void setCategory(Category category) {
        this.category = category;
    }

    @Override
	public String toString() {
		return "Product[" + productId + ", " + productName + ", " + unitPrice+ ", cat=" + getCategory() + ", ver=" + version + "]";
	}
}
