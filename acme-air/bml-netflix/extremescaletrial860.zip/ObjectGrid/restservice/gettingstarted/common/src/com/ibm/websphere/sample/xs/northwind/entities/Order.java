//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind.entities;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ibm.websphere.projector.annotations.Basic;
import com.ibm.websphere.projector.annotations.CascadeType;
import com.ibm.websphere.projector.annotations.Entity;
import com.ibm.websphere.projector.annotations.Id;
import com.ibm.websphere.projector.annotations.IdClass;
import com.ibm.websphere.projector.annotations.ManyToOne;
import com.ibm.websphere.projector.annotations.OneToMany;
import com.ibm.websphere.projector.annotations.Version;

@Entity
@IdClass(OrderId.class)
public class Order {

	@Id
	int orderId;

    @Id
    @ManyToOne(cascade=CascadeType.PERSIST)
    Customer customer;

    /**
     * The version field is used for optimistic locking by
     * eXtreme Scale and is automatically updated.
     */
    @Version
    private int version;

	@Basic
	Date orderDate;

	@Basic
	String shipCity;

	@Basic
	String shipCountry;

	@OneToMany(mappedBy="order", cascade=CascadeType.ALL)
	List<OrderDetail> orderDetails;

	public Order() {
		super();
		orderDetails = new ArrayList<OrderDetail>();
	}

	public Order(int orderId) {
		this.orderId = orderId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getShipCity() {
		return shipCity;
	}

	public void setShipCity(String shipCity) {
		this.shipCity = shipCity;
	}

	public String getShipCountry() {
		return shipCountry;
	}

	public void setShipCountry(String shipCountry) {
		this.shipCountry = shipCountry;
	}

	public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
    }

    @Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("mm/dd/yy hh:mm:ss.SSS");
		return "Order[" + orderId + ", " + sdf.format(orderDate) + ", numOrderDetails=" +
		    (getOrderDetails()==null?0:getOrderDetails().size()) + ", ver=" + version + "]";
	}
}
