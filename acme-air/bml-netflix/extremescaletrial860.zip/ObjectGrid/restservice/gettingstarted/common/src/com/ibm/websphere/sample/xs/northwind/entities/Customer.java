//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind.entities;

import java.util.ArrayList;
import java.util.Collection;

import com.ibm.websphere.projector.annotations.Basic;
import com.ibm.websphere.projector.annotations.CascadeType;
import com.ibm.websphere.projector.annotations.Entity;
import com.ibm.websphere.projector.annotations.Id;
import com.ibm.websphere.projector.annotations.OneToMany;
import com.ibm.websphere.projector.annotations.Version;

@Entity(schemaRoot=true)
public class Customer {

	@Id
	String customerId;

    /**
     * The version field is used for optimistic locking by
     * eXtreme Scale and is automatically updated.
     */
    @Version
    private int version;

	@Basic
	String companyName;

	@Basic
	String contactName;

	@Basic
	String city;

	@Basic
	String country;

	@OneToMany(mappedBy="customer", cascade=CascadeType.ALL)
	Collection<Order> orders;

	public Customer() {
		super();
		orders = new ArrayList<Order>();
	}

	public Customer(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

    public Collection<Order>getOrders() {
        return orders;
    }

    public void setOrders(Collection<Order> orders) {
        this.orders = orders;
    }

	public String toString() {
		return "Customer[" + customerId + ", " + contactName + ", numSalesOrders=" +
		    (getOrders()==null?"0":getOrders().size()) + ", ver=" + version + "]";
	}
}
