//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.ibm.websphere.objectgrid.ObjectGrid;
import com.ibm.websphere.objectgrid.ObjectGridException;
import com.ibm.websphere.objectgrid.PartitionManager;
import com.ibm.websphere.objectgrid.Session;
import com.ibm.websphere.objectgrid.em.EntityManager;
import com.ibm.websphere.objectgrid.em.EntityTransaction;
import com.ibm.websphere.objectgrid.em.Query;
import com.ibm.websphere.projector.annotations.Entity;
import com.ibm.websphere.sample.xs.northwind.entities.Category;
import com.ibm.websphere.sample.xs.northwind.entities.Customer;
import com.ibm.websphere.sample.xs.northwind.entities.Order;
import com.ibm.websphere.sample.xs.northwind.entities.OrderDetail;
import com.ibm.websphere.sample.xs.northwind.entities.OrderId;
import com.ibm.websphere.sample.xs.northwind.entities.Product;
import com.ibm.websphere.sample.xs.northwind.entities.ProductId;

/**
 * Helper class for adding and querying entities in the NorthwindGrid grid.
 */
public class NorthwindDataAccess {

    public static Customer createCustomer(String id,
            String contact, String company) {
        Customer c = new Customer();
        c.setCustomerId(id);
        c.setContactName(contact);
        c.setCompanyName(company);
        return c;
    }

    public static Order createOrder(Customer cust, int id,
            Date orderDate, String shipCity) {
        Order o = new Order();
        o.setOrderId(id);
        o.setOrderDate(orderDate);
        o.setShipCity(shipCity);
        o.setCustomer(cust);
        cust.getOrders().add(o);
        return o;
    }

    public static void addOrderDetail(Order o, int productId,
            int categoryId, float disc, short qty, double price) {
        OrderDetail od = new OrderDetail(o, productId, categoryId);
        od.setDiscount(disc);
        od.setQuantity(qty);
        od.setUnitPrice(price);
        o.getOrderDetails().add(od);
    }

    public static void persistCustomerOrders(Session session,
            String companyId, String contactName, String companyName, int numOrders,
            int firstOrderId, String shipCity, int maxItems, float discount) {
        EntityManager em = session.getEntityManager();
        EntityTransaction tx = em.getTransaction();

        // Get some products to order
        List<ProductInfo> productInfos = getProductInfos(session, 20);

        Random r = new Random();

        // Persist the Customer/Order/OrderDetails
        tx.begin();

        try {
            // Create or find an existing customer with the same name.
            Customer customer = (Customer) em.find(Customer.class, companyId);
            if (customer == null) {
                // Persist the top level relationships and let cascade-persist
                // persist the children.
                customer = createCustomer(companyId, contactName, companyName);
                em.persist(customer);
            }

            // Create some orders and order details for the customer
            for (int orderId = firstOrderId; orderId < firstOrderId + numOrders; orderId++) {
                // Don't create any duplicate orders
                if(em.find(Order.class, new OrderId(orderId, customer)) == null) {
                    Order order = createOrder(customer, orderId, new Date(), shipCity);

                    HashSet<Integer> usedProductIds = new HashSet<Integer>();
                    int numItems = r.nextInt(maxItems) + 1;

                    for (int i = 0; i < numItems; i++) {
                        // Find a random product id, but don't add a duplicate one.
                        ProductInfo productInfo;
                        do {
                            productInfo = productInfos.get(r.nextInt(productInfos.size()));
                        } while (usedProductIds.contains(productInfo.productId));
                        usedProductIds.add(productInfo.productId);

                        // Random quantity
                        int qty = r.nextInt(10)+1;

                        addOrderDetail(order, productInfo.productId, productInfo.categoryId, discount,
                                (short) qty, productInfo.unitPrice);

                    }
                }
            }
        } finally {
            // End the transaction
            if (tx.isActive()) {
                if (tx.getRollbackOnly()) {
                    tx.rollback();
                } else {
                    tx.commit();
                }
            }
        }

    }

    public static Category createCategory(int id, String name, String description) {
        Category c = new Category();
        c.setCategoryId(id);
        c.setCategoryName(name);
        c.setDescription(description);
        return c;
    }

    public static Product createProduct(Category cat, int id) {
        Product p = new Product(id, cat);
        p.setProductName("Product " + id);
        p.setUnitPrice(new Double(4.99));
        p.setUnitsInStock((short) 100);
        cat.getProducts().add(p);
        return p;
    }

    public static void persistCategoryProducts(Session session, int categoryId,
            String categoryName, int firstProductId, int numProducts) {
        EntityManager em = session.getEntityManager();
        EntityTransaction tx = em.getTransaction();

        // Persist the categories and products schema
        tx.begin();

        try {
            // Only create if it's not already there.
            Category cat = (Category) em.find(Category.class, categoryId);
            if (cat == null) {
                cat = createCategory(categoryId, categoryName, "The " + categoryName + " category.");

                // Persist the top level relationships and let cascade-persist
                // persist the children.
                em.persist(cat);
            }

            for (int i = firstProductId; i < firstProductId + numProducts; i++) {
                // Don't create any duplicate products
                if(em.find(Product.class, new ProductId(i*10, cat))==null) {
                    createProduct(cat, i*10);
                }
            }

        } finally {
            // End the transaction
            if (tx.isActive()) {
                if (tx.getRollbackOnly()) {
                    tx.rollback();
                } else {
                    tx.commit();
                }
            }
        }
    }

    public static void loadGrid(ObjectGrid og) throws ObjectGridException {
        Session session = og.getSession();

        // Create some categories and products
        persistCategoryProducts(session, 1, "Computers", 100, 20);
        persistCategoryProducts(session, 2, "Furniture", 200, 15);
        persistCategoryProducts(session, 3, "Office Supplies", 300, 30);

        // Create some customers and orders
        persistCustomerOrders(session, "ACME", "Wile E. Coyote", "ACME Inc.", 10, 1000, "Phoenix", 5, 0.05f);
        persistCustomerOrders(session, "ACME", "Wile E. Coyote", "ACME Inc.", 15, 2000, "Austin", 5, 0.025f);
        persistCustomerOrders(session, "IBM", "Joe Smith", "IBM Corporation", 5, 3000, "Rochester", 10, 0.25f);
        persistCustomerOrders(session, "IBM", "Joe Smith", "IBM Corporation", 20, 4000, "Austin", 10, 0.25f);
        persistCustomerOrders(session, "IBM", "Joe Smith", "IBM Corporation", 25, 5000, "Raleigh", 10, 0.25f);
        persistCustomerOrders(session, "CUST1", "John Doe", "N/A", 2, 6000, "New York", 2, 0f);
    }

    public static void displayCustomer(Session session, String id) throws ObjectGridException {
        EntityManager em = session.getEntityManager();
        em.getTransaction().begin();
        try {
            Customer customer = (Customer) em.find(Customer.class, id);
            if(customer == null) {
                System.out.println("Category not found with id: " + id);
                return;
            }

            System.out.println("Customer: " + customer);
            System.out.println("  Orders: ");
            for(Order order : customer.getOrders()) {
                System.out.println("    " + order);
                System.out.println("      Items: ");
                for(OrderDetail item : order.getOrderDetails()) {
                    System.out.println("        " + item);
                }
            }
        } finally {
            if(em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        }
    }

    public static void displayCategory(Session session, int id) throws ObjectGridException {
        EntityManager em = session.getEntityManager();
        em.getTransaction().begin();
        try {
            Category cat = (Category) em.find(Category.class, id);
            if(cat == null) {
                System.out.println("Category not found with id: " + id);
                return;
            }

            System.out.println("Category: " + cat);
            System.out.println("  Products: ");
            for(Product product : cat.getProducts()) {
                System.out.println("    " + product);
            }
        } finally {
            if(em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        }
    }

    /**
     * Temporary entity that holds the result of the getProductInfos query.
     * The data types and names must match the fields in the query.
     */
    @Entity
    public static class ProductInfo {
        int productId;
        int categoryId;
        Double unitPrice;
    }

    /**
     * Get a list of product id's in the grid.
     * @param session the ObjectGrid session to use
     * @param max the maximum number of id's to return
     * @return a list of product id's up to the max size.
     */
    @SuppressWarnings("unchecked")
    public static List<ProductInfo> getProductInfos(Session session, int max) {
        EntityManager em = session.getEntityManager();

        ArrayList<ProductInfo> productInfos = new ArrayList<ProductInfo>();

            Query q = em.createQuery("SELECT p.productId as productId, p.category.categoryId as categoryId, " +
            		"p.unitPrice as unitPrice FROM Product p");

            PartitionManager pm = session.getObjectGrid().getMap("Product").getPartitionManager();
            int numPartitions = pm.getNumOfPartitions();

            // Iterate through each partition until we find the right number of products.
            int numResults = 0;
            for (int partitionId = 0; partitionId < numPartitions; partitionId++) {
                // Run each query in a separate transaction to a different partition.
                em.getTransaction().begin();
                try {
                    q.setPartition(partitionId);
                    q.setMaxResults(max);
                    Iterator<ProductInfo> result = q.getResultIterator(ProductInfo.class);
                    while (result.hasNext()) {
                        productInfos.add(result.next());
                        if (numResults == max) {
                            break;
                        }
                    }
                    if (numResults == max) {
                        break;
                    }
                } finally {
                    em.getTransaction().rollback();
                }
            }

        return productInfos;
    }

    @SuppressWarnings("unchecked")
    public static void displayCustomerOrderReport(Session session, String custId) throws ObjectGridException {
        EntityManager em = session.getEntityManager();
        em.getTransaction().begin();

        try {
            // Get the partition for the customer id
            int partitionId = session.getObjectGrid().getMap("Customer").getPartitionManager().getPartition(custId);

            Query q = em.createQuery(
                    "SELECT c.companyName, SUM(od.quantity) as SUM_QTY, SUM(od.unitPrice), COUNT(c) as SUM_PRICE "
                    + "FROM Customer c join c.orders o join o.orderDetails od " + "WHERE c.customerId=:customerId "
                    + "GROUP BY c.companyName");
            q.setParameter("customerId", custId);
            q.setPartition(partitionId);
            Iterator<Object[]> resultIterator = q.getResultIterator();
            if(!resultIterator.hasNext()) {
                System.out.println("No orders found.");
            } else {
                Object[] result = resultIterator.next();
                System.out.println("Total Orders for " + custId + "("+ result[0] + "): Qty=" +
                        result[1] + ", Amt=$" + String.format("%,.2f", result[2]) + ", Orders="
                        + result[3]);
            }
        } finally {
            if(em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        }
    }

}
