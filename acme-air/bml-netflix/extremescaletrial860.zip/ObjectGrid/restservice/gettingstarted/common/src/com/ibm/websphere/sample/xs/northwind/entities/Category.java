//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind.entities;

import java.util.ArrayList;
import java.util.List;

import com.ibm.websphere.projector.annotations.Basic;
import com.ibm.websphere.projector.annotations.CascadeType;
import com.ibm.websphere.projector.annotations.Entity;
import com.ibm.websphere.projector.annotations.Id;
import com.ibm.websphere.projector.annotations.OneToMany;
import com.ibm.websphere.projector.annotations.Version;

@Entity(schemaRoot=true)
public class Category  {

	@Id
	int categoryId;

    /**
     * The version field is used for optimistic locking by
     * eXtreme Scale and is automatically updated.
     */
    @Version
    private int version;

	@Basic
	String categoryName;

	@Basic
	String description;

	@OneToMany(mappedBy="category", cascade=CascadeType.ALL)
	List<Product> products;

	public Category() {
		super();
		products = new ArrayList<Product>();
	}

	public Category(int categoryId) {
		super();
		this.categoryId = categoryId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    @Override
	public String toString() {
		return "Category[" + categoryId + ", " + categoryName + ", numProducts=" +
		    (getProducts()==null?"0":getProducts().size()+"") + ", ver=" + version + "]";
	}
}
