#!/bin/sh

#  This sample program is provided AS IS and may be used, executed, copied and modified
#  without royalty payment by customer
#  (a) for its own instruction and study,
#  (b) in order to develop applications designed to run with an IBM WebSphere product,
#  either for customer's own internal use or for redistribution by customer, as part of such an
#  application, in customer's own products.
#  Licensed Materials - Property of IBM
#  5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009

# Setup our environment variables.
fileDir=`dirname ${0}`
. "$fileDir"/env.sh

# Ensure there is at least 1 arguments.
usage ()
{
    echo Missing argument.
    echo Command line syntax:  runcontainer [Unique Container Name]
}

if [ $# -lt 1 ]
then
    usage
    exit
fi

CONTAINER_NAME="$1"

if [ ! -z $WXS_INSTALLATION ]
then
  # Start the XS container server process in stand alone configuration
  $JAVA_EXE -classpath "$OG_CLASSPATH:$SAMPLE_SERVER_CLASSPATH" "$OBJECTGRID_ENDORSED_DIRS" -Djava.util.logging.manager=com.ibm.ws.bootstrap.WsLogManager -Djava.util.logging.configureByServer=true com.ibm.ws.objectgrid.InitializationService "$CONTAINER_NAME" -catalogServiceEndPoints $CATALOGSERVER_HOST:$CATALOGSERVER_PORT -objectgridFile server/bin/META-INF/objectGrid.xml -deploymentPolicyFile server/bin/META-INF/objectGridDeployment.xml
else
  # Start the XS container server process in WAS configuration
  $JAVA_EXE -classpath $JAVA_HOME/lib/tools.jar:$WAS_CLASSPATH $WAS_LOGGING $CONSOLE_ENCODING -Dws.ext.dirs=$WAS_EXT_DIRS:$WAS_HOME/plugins:$SAMPLE_SERVER_CLASSPATH -Dwas.install.root=$WAS_HOME -Duser.install.root=$USER_INSTALL_ROOT -Dobjectgrid.home=$WAS_HOME com.ibm.ws.bootstrap.WSLauncher com.ibm.ws.objectgrid.InitializationService "$CONTAINER_NAME" -catalogServiceEndPoints $CATALOGSERVER_HOST:$CATALOGSERVER_PORT -objectgridFile server/bin/META-INF/objectGrid.xml -deploymentPolicyFile server/bin/META-INF/objectGridDeployment.xml
fi
