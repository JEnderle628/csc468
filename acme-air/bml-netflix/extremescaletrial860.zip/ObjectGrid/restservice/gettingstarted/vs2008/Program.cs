﻿//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Services.Client;

namespace com.ibm.websphere.sample.xs.northwind
{
    using GettingStartedService;

    /// <summary>
    /// This C# ADO.Net Data Services client application demonstrates how to communicate with
    /// the WebSphere eXtreme Scale REST data service.  
    /// </summary>
    class Program
    {
        private NorthwindGridEntities svcContext;

        /// <summary>
        /// Create an instance of the Program sample
        /// </summary>
        /// <param name="url">The url hosting the WXS Northwind data service</param>
        public Program(String url)
        {
            Console.WriteLine("Connecting to data service: " + url);
            svcContext = new NorthwindGridEntities(new Uri(url));
        }

        /// <summary>
        /// Main method to execute the Load and Display operations on the configured grid.
        /// </summary>
        /// <param name="args">Command line arguments</param>
        static void Main(string[] args)
        {
            if (args.Length < 2)
            {
                printUsage();
                return;
            }

            Program p = new Program(args[0]);
            try
            {
                if (args[1].StartsWith("l"))
                {
                    //load
                    if (args[2].StartsWith("d"))
                    {
                        //load default
                        Console.WriteLine("Loading the grid with the default set of Customers and Categories.");
                        p.loadGrid();
                    }
                    else if (args[2].StartsWith("cu"))
                    {
                        //load customer
                        if (args.Length != 11)
                        {
                            printUsage();
                            return;
                        }
                        Console.WriteLine("Loading the grid with a new Customer and Orders...");
                        p.persistCustomerOrders(args[3], args[4], args[5], 
                                                Int32.Parse(args[6]), Int32.Parse(args[7]), 
                                                args[8], Int32.Parse(args[9]), float.Parse(args[10]));                        
                    }
                    else if (args[2].StartsWith("ca"))
                    {
                        //load category
                        if (args.Length != 7)
                        {
                            printUsage();
                            return;
                        }
                        Console.WriteLine("Loading the grid with a new category and products...");
                        p.persistCategoryProducts(Int32.Parse(args[3]), args[4], Int32.Parse(args[5]),
                                                  Int32.Parse(args[6]));
                    }
                    else
                    {
                        // load <unknown>
                        printUsage();
                        return;
                    }
                }
                else if (args[1].StartsWith("d"))
                {
                    //Display
                    if (args[2].StartsWith("cu"))
                    {
                        // Display Customer
                        if (args.Length != 4)
                        {
                            printUsage();
                            return;
                        }
                        Console.WriteLine("Displaying Customer report for customer code: " + args[3]);
                        p.displayCustomer(args[3]);
                    }
                    else if (args[2].StartsWith("ca"))
                    {
                        //Display Category
                        // Display Customer
                        if (args.Length != 4)
                        {
                            printUsage();
                            return;
                        }
                        Console.WriteLine("Displaying Category report for category code: " + args[3]);
                        p.displayCategory(Int32.Parse(args[3]));
                        
                    }
                    else
                    {
                        //display <unknown>
                        printUsage();
                        return;  
                    }
                }
                else if (args[1].StartsWith("u"))
                {
                    // unload
                    Console.WriteLine("Unloading all entities loaded with 'load default'...");
                    p.unloadGrid();
                }
                else
                {
                    Console.WriteLine("Unknown operation: " + args[1]);
                    printUsage();
                }

            }
            catch (DataServiceRequestException ex)
            {
                Console.WriteLine(ex);

            }

            Console.WriteLine("Operation Complete.");
            Console.WriteLine("Press any key");
            Console.ReadKey();
        }

        /// <summary>
        /// When run with no arguments or incorrect arguments, inform the user of the usage
        /// patterns.
        /// </summary>
        private static void printUsage()
        {
            Console.WriteLine("This program persists and queries entities in the NorthwindGrid.");
            Console.WriteLine();
            Console.WriteLine("script usage: WXSRESTGettingStarted.exe <data service uri> <command>");
            Console.WriteLine();
            Console.WriteLine("The following commands are available:");
            Console.WriteLine("  load default");
            Console.WriteLine("  load customer <companyCode> <contactName> <companyName> <numOrders> <firstOrderId> <shipCity> <maxItems> <discountPct>");
            Console.WriteLine("  load category <categoryId> <categoryName> <firstProductId> <numProducts>");
            Console.WriteLine("  display customer <companyCode>");
            Console.WriteLine("  display category <categoryId>");
            Console.WriteLine("  unload");
            Console.WriteLine();
            Console.WriteLine("Examples:");
            Console.WriteLine("... load default");
            Console.WriteLine("... load customer IBM \"John Doe\" \"IBM Corporation\" 5 5000 Rochester 5 0.05");
            Console.WriteLine("... load category 5 \"Household Items\" 100 5");
            Console.WriteLine("... display customer IBM");
            Console.WriteLine("... display category 5");
        }

        /// <summary>
        /// Display a customer's infromation, order, and order details
        /// </summary>
        /// <param name="id">The id of the customer to display</param>
        public void displayCustomer(String id) {
            Customer customer = getCustomer(id);
            if(customer == null) {
                Console.WriteLine("Customer not found with id: " + id);
                return;
            }

            Console.WriteLine("Customer: " + customerToString(customer));
            Console.WriteLine("  Orders: ");
            foreach (Order order in customer.orders) {
                Console.WriteLine("    " + orderToString(order));
                Console.WriteLine("      Items: ");
                svcContext.LoadProperty(order, "orderDetails");
                foreach (OrderDetail item in order.orderDetails) {
                    Console.WriteLine("        " + orderDetailToString(item));
                }
            }
        }

        /// <summary>
        /// Display a category's information and associated products.
        /// </summary>
        /// <param name="id">The id of the category to display.</param>
        public void displayCategory(int id) {
            Category cat = findCategory(id, true);
            if(cat == null) {
                Console.WriteLine("Category not found with id: " + id);
                return;
            }

            Console.WriteLine("Category: " + categoryToString(cat));
            Console.WriteLine("  Products: ");
            foreach (Product product in cat.products) {
                Console.WriteLine("    " + productToString(product));
            }
        }

        /// <summary>
        /// Load the grid with a set of default information, including customers,
        /// orders, order details, categories, and products.
        /// </summary>
        public void loadGrid()
        {
            //Create some categories and products
            Console.WriteLine("Creating Computers...");
            persistCategoryProducts(1, "Computers", 100, 20);
            Console.WriteLine("Creating Furniture...");
            persistCategoryProducts(2, "Furniture", 200, 15);
            Console.WriteLine("Creating Office Supplies...");
            persistCategoryProducts(3, "Office Supplies", 300, 30);

            // Create some customers and orders
            Console.WriteLine("Creating ACME Phoenix Orders...");
            persistCustomerOrders("ACME", "Wile E. Coyote", "ACME Inc.", 10, 11111, "Phoenix", 5, 0.05f);
            Console.WriteLine("Creating ACME Austin Orders...");
            persistCustomerOrders("ACME", "Wile E. Coyote", "ACME Inc.", 15, 22222, "Austin", 5, 0.025f);
            Console.WriteLine("Creating IBM Rochester Orders...");
            persistCustomerOrders("IBM", "Joe Smith", "IBM Corporation", 5, 33333, "Rochester", 10, 0.25f);
            Console.WriteLine("Creating IBM Austin Orders...");
            persistCustomerOrders("IBM", "Joe Smith", "IBM Corporation", 20, 44444, "Austin", 10, 0.25f);
            Console.WriteLine("Creating IBM Raliegh Orders...");
            persistCustomerOrders("IBM", "Joe Smith", "IBM Corporation", 25, 55555, "Raleigh", 10, 0.25f);
            Console.WriteLine("Creating CUST1 New York Orders...");
            persistCustomerOrders("CUST1", "John Doe", "N/A", 2, 66666, "New York", 2, 0f);

        }

        /// <summary>
        /// Remove all of the entities loaded by the loadgrid method.
        /// </summary>
        public void unloadGrid()
        {
            deleteCategory(1);
            deleteCategory(2);
            deleteCategory(3);
            deleteCategory(4);

            deleteCustomerAndOrders("ACME");
            deleteCustomerAndOrders("IBM");
            deleteCustomerAndOrders("CUST1");
        }

        /// <summary>
        /// Create a new Customer and some associated Orders and Order Details
        /// </summary>
        /// <param name="companyId">The new customer's id</param>
        /// <param name="contactName">The new contact name</param>
        /// <param name="companyName">The new company name</param>
        /// <param name="numOrders">The number of orders to create</param>
        /// <param name="firstOrderId">The id at which to start the first new order</param>
        /// <param name="shipCity">The city to ship the orders to</param>
        /// <param name="maxItems">The maximum number of order details to create for an order</param>
        /// <param name="discount">The discoutn to apply to an order detail</param>
        public void persistCustomerOrders(String companyId,
                                          String contactName,
                                          String companyName,
                                          int numOrders,
                                          int firstOrderId,
                                          String shipCity,
                                          int maxItems,
                                          float discount)
        {
            //Get the products for the first three categories (assumes a default loaded grid)
            List<Product> products = new List<Product>();
            for (int i = 1; i <= 3; i++)
            {
                products.AddRange(getProducts(i));
            }

            if (products.Count == 0)
            {
                Console.WriteLine("There are no products.  Load the default category and products first.");
                return;
            }

            Random r = new Random();

            //see if customer exists
            Customer c = getCustomer(companyId);
            if (c == null)
            {
                //if not, create
                c = addCustomer(companyId, contactName, companyName);
            }

            //create order and orderdetails
            for (int orderId = firstOrderId; orderId < firstOrderId + numOrders; orderId++)
            {
                //avoid duplicates
                if (findOrder(orderId, c.customerId) == null)
                {
                    Order o = addOrder(c, orderId, shipCity);

                    HashSet<int> usedPids = new HashSet<int>();
                    int numItems = r.Next(maxItems) + 1;

                    for (int i = 0; i < numItems; i++)
                    {
                        //random product, but don't order same product twice
                        Product p;                        
                        do
                        {
                            p = products.ElementAt(r.Next(products.Count()));
                        } while (usedPids.Contains(p.productId));
                        usedPids.Add(p.productId);

                        // random quantity
                        int qty = r.Next(10) + 1;

                        addOrderDetail(o, p, (short)qty, (decimal)p.unitPrice, discount);
                    }
                }
            }

            Console.WriteLine("Saving Changes...");
            svcContext.SaveChanges(SaveChangesOptions.Batch);
        }

        /// <summary>
        /// Create the actual customer entity.
        /// </summary>
        /// <param name="customerId">The id for the new customer</param>
        /// <param name="contactName">The contact name for the new customer</param>
        /// <param name="companyName">The company name for the new customer</param>
        /// <returns>A reference to the newly created customer</returns>
        public Customer addCustomer(String customerId, String contactName, String companyName)
        {
            long customerCounter = System.DateTime.Now.Ticks;
            // Create new customer          

            // only have 5 chars so randomize and hope...

            Customer newCustomer = new Customer();
            newCustomer.customerId = customerId;
            newCustomer.companyName = companyName;
            newCustomer.contactName = contactName;
            newCustomer.country = "country" + customerCounter % 99999;
            newCustomer.city = "city" + customerCounter % 99999;

            //add to context
            svcContext.AddToCustomer(newCustomer);

            return newCustomer;
        }

        /// <summary>
        /// Create a new order for a given customer
        /// </summary>
        /// <param name="c">The customer to create the order for</param>
        /// <param name="orderId">The id for the new order</param>
        /// <param name="shipCity">The city to ship the order to</param>
        /// <returns>A reference to the newly created order</returns>
        private Order addOrder(Customer c, int orderId, String shipCity)
        {
            long orderCounter = System.DateTime.Now.Ticks;
            //Create the new Order
            Order newOrder = new Order();
            newOrder.orderId = orderId;
            newOrder.shipCity = shipCity;
            newOrder.orderDate = System.DateTime.Now;
            newOrder.shipCountry = "shipCtry" + orderCounter % 99999;

            svcContext.AddToOrder(newOrder);

            //set relationship

            c.orders.Add(newOrder);
            svcContext.AddLink(c, "orders", newOrder);

            // Set the reference and the foreign keys
            newOrder.customer = c;
            newOrder.customer_customerId = c.customerId;
            svcContext.SetLink(newOrder, "customer", c);

            return newOrder;
        }  

        /// <summary>
        /// Create a new Order Detail for a given order and add it to the service context.
        /// </summary>
        /// <param name="currentOrder">The order to create the order detail for</param>
        /// <param name="p">The product which the order detail represents</param>
        /// <param name="qty">The quantity to order</param>
        /// <param name="unitPrice">The unit price for the order detail</param>
        /// <param name="discount">The discount to apply to the order detail</param>
        /// <returns>A refrence to the new order detail</returns>
        private OrderDetail addOrderDetail(Order currentOrder, Product p, short qty, decimal unitPrice, float discount)
        {
            // Create a new OrderDetail object with the supplied FK values.
            
            OrderDetail newItem = new OrderDetail();
            newItem.productId = p.productId;
            newItem.discount = discount;
            newItem.unitPrice = (double)unitPrice;
            newItem.quantity = qty;
            newItem.order = currentOrder;
            // Add the new item to the context.
            svcContext.AddToOrderDetail(newItem);

            // Add the relationship between the order and the new item.
            currentOrder.orderDetails.Add(newItem);
            svcContext.AddLink(currentOrder, "orderDetails", newItem);

            // Set the reference to the order and product from the item.
            newItem.order = currentOrder;
            newItem.categoryId = p.category_categoryId;
            newItem.order_customer_customerId = currentOrder.customer_customerId;
            newItem.order_orderId = currentOrder.orderId;
            svcContext.SetLink(newItem, "order", currentOrder);

            return newItem;
        }

        /// <summary>
        /// Retrieve all products for a given category.  The category link is expanded.
        /// </summary>
        /// <param name="categoryId">The category to retrieve products for</param>
        /// <returns>A list of products associated with the given category</returns>
        public List<Product> getProducts(int categoryId)
        {
            // For the given category, retrieve all of the products.
            Category cat = null;
            try
            {
                // Get the category by primary key using a query
                DataServiceQuery<Category> categories = (DataServiceQuery<Category>)
                    from c in svcContext.Category.Expand("products/category") where c.categoryId == categoryId select c;
                cat = categories.First();
                if(cat == null) 
                {
                    return new List<Product>();
                }
            }
            catch (DataServiceQueryException ex)
            {
                // Not found
                if (ex.Response.StatusCode == 404)
                {
                    return new List<Product>();
                }
                throw ex;
            }

            List<Product> products = cat.products.ToList<Product>();

            return products;

        }

        /// <summary>
        /// Remove a given customer, their orders, and order details and save the changes.
        /// </summary>
        /// <param name="custId">The id of the customer to remove</param>
        public void deleteCustomerAndOrders(String custId)
        {
            Console.WriteLine("Finding Customer: " + custId);
            Customer c = getCustomer(custId);

            if (c != null)
            {
                //customer found.. remove
                Console.WriteLine("Found Customer: " + c.customerId);

                foreach (Order ord in c.orders)
                {
                    //remove each order
                    svcContext.LoadProperty(ord, "orderDetails");
                    foreach (OrderDetail ordd in ord.orderDetails)
                    {
                        //remove each order detail
                        Console.WriteLine("Deleting Order Detail: " + ordd.productId);
                        svcContext.DeleteObject(ordd);
                    }
                    Console.WriteLine("Deleting order: " + ord.orderId);
                    svcContext.DeleteObject(ord);
                }
                Console.WriteLine("Deleting customer: " + c.customerId);
                svcContext.DeleteObject(c);

                Console.WriteLine("Saving Changes...");
                svcContext.SaveChanges(SaveChangesOptions.Batch);
            }
            else
            {
                //coulsn't find the customer
                Console.WriteLine("Couldn't find Customer: " + custId);
            }
        }

        /// <summary>
        /// Retrieve a customer with a given id
        /// </summary>
        /// <param name="id">The id of the customer to retrieve.</param>
        /// <returns>A reference to the customer.  Null if not found.</returns>
        public Customer getCustomer(String id)
        {
            try
            {
                return svcContext.Customer.Expand("orders").Where(c => c.customerId == id).FirstOrDefault();
            }
            catch (DataServiceQueryException ex)
            {
                // Not found
                if (ex.Response.StatusCode == 404)
                {
                    return null;
                }
                throw ex;
            }
        }

        /// <summary>
        /// Retrieve an order with the given id and customer
        /// </summary>
        /// <param name="orderId">The id of the order to retrieve.</param>
        /// <param name="custId">The id of the customer whose order will be retrieved.</param>
        /// <returns>A reference to the retrieved order.  Null if not found.</returns>
        public Order findOrder(long orderId, String custId)
        {
            try
            {
                // Retrieve the orders for the given customer using an explicit query.
                // The ADO.Net Data Service generates the composite key as a $filter instead of
                // a key lookup, so we need to build the URL directly.
                return svcContext.Execute<Order>(new Uri(svcContext.BaseUri.AbsoluteUri +
                    "/Order(orderId=" + orderId + ",customer_customerId='" + custId + "')?$expand=customer")).FirstOrDefault();

                // Normally, we'd like to do this:
                //return svcContext.Order.Where(o => o.orderId == orderId && o.customer_customerId == custId).FirstOrDefault();
            }
            catch (DataServiceQueryException ex)
            {
                // Not found
                if (ex.Response.StatusCode == 404)
                {
                    return null;
                }
                throw ex;
            }
        }

        /// <summary>
        /// Retrieve the category with a given id, expanding the products and the product's 
        /// category references.
        /// </summary>
        /// <param name="id">The id of the category to retrieve</param>
        /// <param name="eager">if true, expand products, otherwise just return categories</param>
        /// <returns>The category with the given id</returns>
        public Category findCategory(int id, bool eager)
        {
            // When an entity isn't found, it returns a 404 not found instead of a null result.
            try
            {
                if (eager)
                {
                    return svcContext.Category.Expand("products/category").Where(e => e.categoryId == id).First();
                }
                return svcContext.Category.Where(e => e.categoryId == id).First();
            }
            catch (DataServiceQueryException ex)
            {
                // Not found
                if (ex.Response.StatusCode == 404)
                {
                    return null;
                }
                throw ex;
            }
        }

        /// <summary>
        /// Create a new category and add it to the context.
        /// </summary>
        /// <param name="categoryId">The id of the new category</param>
        /// <param name="name">The name of the new category</param>
        /// <param name="description">A description for the new category</param>
        /// <returns>A reference to the newly created category</returns>
        public Category createCategory(int categoryId, String name, String description) 
        {
            Console.WriteLine("Creating Category: " + categoryId);

            Category c = new Category();
            c.categoryId = categoryId;
            c.categoryName = name;
            c.description = description;

            svcContext.AddToCategory(c);
            return c;
        }

        /// <summary>
        /// Create a new product, link it to the category and add it to the context.
        /// </summary>
        /// <param name="cat">The category to associate with the new product</param>
        /// <param name="prodId">The id for the new product</param>
        /// <returns>A reference to the newly created product</returns>
        public Product createProduct(Category cat, int prodId)
        {
            Product p = findProduct(cat.categoryId, prodId);

            if (p != null)
            {
                Console.WriteLine("Found Product: " + prodId);
                return p;
            }
            Console.WriteLine("Creating Product: " + prodId);
            p = new Product();
            p.productId = prodId;
            p.productName = "Product " + prodId;
            p.unitPrice = 4.99;
            p.unitsInStock = 100;

            // References
            p.category = cat;
            p.category_categoryId = cat.categoryId;
            cat.products.Add(p);

            // Persist
            svcContext.AddToProduct(p);

            // Cross link
            svcContext.AddLink(cat, "products", p);
            svcContext.SetLink(p, "category", cat);
            return p;
        }

        /// <summary>
        /// Retrieve the product with a given category and product id, expanding the
        /// reference to the category.
        /// </summary>
        /// <param name="catId">The category of the product to retrieve</param>
        /// <param name="prodId">The id of the product to retrieve</param>
        /// <returns>A reference to the retrieved product</returns>
        public Product findProduct(int catId, int prodId) 
        {
                try
            {
                // Need to query the product using the Execute method so we can specify the 
                // composite key.  
                // The ADO.Net Data Service generates the composite key as a $filter instead of
                // a key lookup, so we need to build the URL directly.
                return svcContext.Execute<Product>(new Uri(svcContext.BaseUri.AbsoluteUri +
                       "/Product(productId=" + prodId + ",category_categoryId=" + catId + 
                       ")?$expand=category")).FirstOrDefault();
            }
            catch (DataServiceQueryException ex)
            {
                // Not found
                if (ex.Response.StatusCode == 404)
                {
                    return null;
                }
                throw ex;
            } 
        }

        /// <summary>
        /// Create a new category and some associated products and save the changes.
        /// </summary>
        /// <param name="categoryId">The id for the new category</param>
        /// <param name="categoryName">A name for the new category</param>
        /// <param name="firstProductId">The id for the first create product</param>
        /// <param name="numProducts">The number of products to create in the category</param>
        public void persistCategoryProducts(int categoryId,
                String categoryName, int firstProductId, int numProducts) 
        {
            // Only create if it's not already there.
            Category cat = findCategory(categoryId, false);

            if (cat == null) {
                cat = createCategory(categoryId, categoryName, "The " + categoryName + " category.");
            }

            for (int i = firstProductId; i < firstProductId + numProducts; ++i) {
                createProduct(cat, i);
            }

            // Store the category and associated products in a single batch.
            Console.WriteLine("Saving Changes...");
            svcContext.SaveChanges(SaveChangesOptions.Batch);

        }

        /// <summary>
        /// Remove a category with the given id and save teh changes.
        /// </summary>
        /// <param name="categoryId">The id of the category to remove</param>
        /// <param name="cascade">if true, remove all products, otherwise leave them</param>
        public void deleteCategory(int categoryId)
        {
            // Find the category.  If found, delete it.  
            // The associated products are automatically deleted since 
            // the entity relationship has CascadeType.REMOVE defined.

            Category cat = findCategory(categoryId, false);

            if (cat != null)
            {
                Console.WriteLine("Deleting category and products: " + cat.categoryName);
                svcContext.DeleteObject(cat);

                Console.WriteLine("Saving changes...");
                svcContext.SaveChanges();
            }
            else
            {
                Console.WriteLine("Category not found: " + categoryId);
            }
        }

        /// <summary>
        /// Create a string representing a customer, their orders and order details
        /// </summary>
        /// <param name="c">The customer to stringify</param>
        /// <returns>A String representing the customer</returns>
        public String customerToString(Customer c)
        {
            return "Customer[" + c.customerId + ", " + c.contactName + ", numSalesOrders=" +
                (c.orders == null ? "0" : c.orders.Count().ToString()) + ", ver=" + c.version + "]";
        }

        /// <summary>
        /// Create a string representing an order, and it's order details
        /// </summary>
        /// <param name="o">The order to stringify</param>
        /// <returns>A String representing the order</returns>
        public String orderToString(Order o)
        {            
            return "Order[" + o.orderId + ", numOrderDetails=" +
                (o.orderDetails == null ? "0" : o.orderDetails.Count().ToString()) + ", ver=" + o.version + "]";
        }

        /// <summary>
        /// Create a string representing an order detail
        /// </summary>
        /// <param name="od">The order detail to stringify</param>
        /// <returns>A String representing the order detail</returns>
        public String orderDetailToString(OrderDetail od)
        {
            return "OrderDetail[(orderId=" + od.order_orderId + ", catId=" + od.categoryId + ", prodID=" + od.productId + "), qty=" + od.quantity + ", unitPrice="
                    + od.unitPrice + ", discount=" + od.discount + ", ver=" + od.version + "]";
        }

        /// <summary>
        /// Create a string representing a category and it's products
        /// </summary>
        /// <param name="c">The category to stringify</param>
        /// <returns>A String representing the category</returns>
        public String categoryToString(Category c)
        {
            return "Category[" + c.categoryId + ", " + c.categoryName + ", numProducts=" +
                (c.products == null ? "0" : c.products.Count().ToString() + "") + ", ver=" + c.version + "]";
        }

        /// <summary>
        /// Create a string representing a product
        /// </summary>
        /// <param name="p">The product to stringify</param>
        /// <returns>A String representing the product</returns>
        public String productToString(Product p)
        {
            return "Product[" + p.productId + ", " + p.productName + ", " + p.unitPrice + ", cat=" + p.category_categoryId + ", ver=" + p.version + "]";
        }
    }
}
