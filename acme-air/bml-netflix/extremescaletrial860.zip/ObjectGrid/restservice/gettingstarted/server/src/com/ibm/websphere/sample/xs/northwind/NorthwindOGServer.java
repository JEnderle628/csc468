//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind;
import java.net.URL;

import com.ibm.websphere.objectgrid.ObjectGridException;
import com.ibm.websphere.objectgrid.deployment.DeploymentPolicy;
import com.ibm.websphere.objectgrid.deployment.DeploymentPolicyFactory;
import com.ibm.websphere.objectgrid.server.CatalogServerProperties;
import com.ibm.websphere.objectgrid.server.Container;
import com.ibm.websphere.objectgrid.server.Server;
import com.ibm.websphere.objectgrid.server.ServerFactory;
import com.ibm.websphere.objectgrid.server.ServerProperties;

/**
 * Create an eXtreme Scale catalog service and container within this process.
 */
public class NorthwindOGServer {

    /**
     * Start an ObjectGrid catalog service and container in this process.
     */
    public static void startEmbeddedContainer() throws ObjectGridException {

        URL ogXML = Thread.currentThread().getContextClassLoader().getResource(
                "META-INF/objectGrid.xml");
        if (ogXML == null)
            throw new NullPointerException();

        URL depXML = Thread.currentThread().getContextClassLoader().getResource(
                "META-INF/objectGridDeployment.xml");
        if (depXML == null)
            throw new NullPointerException();

        // Configure any ports for the servers running in this process.
        ServerProperties svrProps = ServerFactory.getServerProperties();
        svrProps.setListenerPort(2909);

        // Enable an embedded catalog service
        CatalogServerProperties catProps = ServerFactory.getCatalogProperties();
        catProps.setCatalogServer(true);

        // Start the containers and catalog service.
        Server s = ServerFactory.getInstance();
        DeploymentPolicy dp = DeploymentPolicyFactory.createDeploymentPolicy(depXML, ogXML);
        Container[] containers = new Container[2];
        containers[0] = s.createContainer(dp);
    }

	public static void main(String[] args) throws Exception {
		startEmbeddedContainer();
	}
}
