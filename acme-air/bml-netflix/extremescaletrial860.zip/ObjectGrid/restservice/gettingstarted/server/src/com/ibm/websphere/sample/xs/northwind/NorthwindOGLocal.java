//
//This sample program is provided AS IS and may be used, executed, copied and
//modified without royalty payment by customer (a) for its own instruction and
//study, (b) in order to develop applications designed to run with an IBM
//WebSphere product, either for customer's own internal use or for redistribution
//by customer, as part of such an application, in customer's own products. "
//
//5724-J34 (C) COPYRIGHT International Business Machines Corp. 2009
//All Rights Reserved * Licensed Materials - Property of IBM
//
package com.ibm.websphere.sample.xs.northwind;

import java.net.URL;

import com.ibm.websphere.objectgrid.ObjectGrid;
import com.ibm.websphere.objectgrid.ObjectGridException;
import com.ibm.websphere.objectgrid.ObjectGridManager;
import com.ibm.websphere.objectgrid.ObjectGridManagerFactory;
import com.ibm.websphere.objectgrid.Session;

/**
 * Create an in-memory grid to validate our configuration.
 */
public class NorthwindOGLocal {

    public static ObjectGrid createLocalObjectGrid() throws ObjectGridException {

        URL ogXML = Thread.currentThread().getContextClassLoader().getResource(
                "META-INF/objectGrid.xml");
        if (ogXML == null)
            throw new NullPointerException();

        ObjectGridManager ogm = ObjectGridManagerFactory.getObjectGridManager();

        ObjectGrid og = ogm.createObjectGrid("NorthwindGrid", ogXML);
        og.initialize();

        return og;
    }


	public static void main(String[] args) throws Exception {
		ObjectGrid og = createLocalObjectGrid();
		Session session = og.getSession();
		NorthwindDataAccess.loadGrid(og);
		NorthwindDataAccess.displayCustomer(session, "ACME");
		NorthwindDataAccess.displayCustomerOrderReport(session, "ACME");
        NorthwindDataAccess.displayCustomer(session, "IBM");
        NorthwindDataAccess.displayCustomerOrderReport(session, "IBM");
	}
}
