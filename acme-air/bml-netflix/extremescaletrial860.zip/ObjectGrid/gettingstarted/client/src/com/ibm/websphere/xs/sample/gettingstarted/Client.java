package com.ibm.websphere.xs.sample.gettingstarted;

/**
 * COPYRIGHT LICENSE:  This information contains sample code provided in source code form. 
 * You may copy, modify, and distribute these sample programs in any form without payment to 
 * IBM for the purposes of developing, using, marketing or distributing application programs conforming 
 * to the application programming interface for the operating platform for which the sample code is written. 
 * Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE ON AN "AS IS" BASIS AND IBM 
 * DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR 
 * CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND ANY WARRANTY 
 * OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR 
 * CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO 
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE SAMPLE SOURCE CODE.  
 *
 * This sample program is provided AS IS and may be used, executed, copied and
 * modified without royalty payment by customer (a) for its own instruction and
 * study, (b) in order to develop applications designed to run with an IBM
 * WebSphere product, either for customer's own internal use or for redistribution
 * by customer, as part of such an application, in customer's own products. 
 * 
 * 5724-X67, 5655-V66 (C) COPYRIGHT International Business Machines Corp. 2012
 * All Rights Reserved * Licensed Materials - Property of IBM
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

import com.ibm.websphere.objectgrid.ClientClusterContext;
import com.ibm.websphere.objectgrid.ObjectGrid;
import com.ibm.websphere.objectgrid.ObjectGridException;
import com.ibm.websphere.objectgrid.ObjectGridManagerFactory;
import com.ibm.websphere.objectgrid.ObjectMap;
import com.ibm.websphere.objectgrid.Session;
import com.ibm.websphere.objectgrid.Session.TxCommitProtocol;
import com.ibm.websphere.xs.sample.gettingstarted.model.TestKey;
import com.ibm.websphere.xs.sample.gettingstarted.model.TestValue;

/**
 * This simple ObjectGrid client that connects to a remote ObjectGrid
 * and allows CRUD operations from the command-line.<p>
 *
 * For details on how to run this program see the GETTINGSTARTED_README.txt
 * file or the ECLIPSE_README.txt included with this sample.
 */
public class Client {
    
    /**
     * The ObjectGrid instance is cached for the life of the application.
     */
    private ObjectGrid grid;

    /**
     * Connect to a remote ObjectGrid
     * @param cep the catalog server end points in the form: <host>:<port>
     * @param gridName the name of the ObjectGrid to connect to that is managed by the Catalog Service
     * @return a client ObjectGrid connection.
     * @throws an ObjectGridException if we can't connect to the grid.
     */
    public static ObjectGrid connectClient(String cep, String gridName) throws ObjectGridException {
        try {
            // Connect to the Catalog Server.  The security and client override XML are not specified.
            ClientClusterContext ccc = ObjectGridManagerFactory.getObjectGridManager().connect(cep, null, null);

            // Retrieve the ObjectGrid client connection and return it.
            ObjectGrid grid = ObjectGridManagerFactory.getObjectGridManager().getObjectGrid(ccc, gridName);
            return grid;
        } catch (ObjectGridException e) {
            // Wrap the exception with a new one, with some message details.
            throw new ObjectGridException("Unable to connect to catalog server at endpoints:" + cep, e);
        }
    }

    /**
     * The program main.  There are four arguments:<p>
     * [0] The catalog server end points in the form <host>:<port>
     * [1] The single-character ObjectGrid CRUD operation to perform:  i=insert, u=update, p=upsert, d=delete, g=get, n=insert n key/values
     * [2] The key.
     * [3] The value.
     *
     * @param args the arguments as previously defined.
     */
    public static void main(String[] args) {
        Client client = new Client();
        client.run(args);
    }
    
    /**
     * Run the client sample.
     * @param args the arguments as previously defined.
     * @see #main(String[])
     */
    public void run(String[] args) {

        // Connect to a remote ObjectGrid, these are the defaults
        String cep = "localhost:2809";
        String gridName = "Grid";
        String mapName = "Map1";
        
        if(args != null && args.length >= 1)
            cep = args[0];
        
        if(args != null && args.length >= 2)
            gridName = args[1];
        
        if(args != null && args.length >= 3)
            mapName = args[2];
        
        try {
            grid = connectClient(cep, gridName);
            System.out.println("Connected to ObjectGrid:  " + grid.getName());
        } catch (ObjectGridException e) {
            // If we can't connect to the grid, just return;
            e.printStackTrace();
            return;
        }

        try {
            if (args != null && args.length > 3) {
                // Run a single command using an automatic transaction and exit
                // grab info from the user input and create an object for key and value
                // these objects canl be stored inside the grid when an operation is performed
                try {
                	String cmd = args[3];	
                	if (cmd.equals("n")) {
                		String k = args[4];
                		// for inserting multiple objects command
                		runCommandAutoTx(mapName, cmd, k, null);
                	}
                	else {
                		TestKey k = new TestKey(args[4]);
                		TestValue v = args.length >= 6 ? new TestValue(args[5]) : null;
                		runCommandAutoTx(mapName, cmd, k, v);
                	}
                } catch (ObjectGridException e) {
                    e.printStackTrace();
                }
            } else {
                // Run in interactive mode.
                // This environment uses a single Session to allow demarcating the transaction.
                Session sess;
                try {
                    sess = grid.getSession();
                } catch (ObjectGridException e) {
                    // If we can't get a session, we can't do anything.
                    e.printStackTrace();
                    return;
                }
                
                try {
                    while (true) {
                        System.out.println();
                        System.out.println("Enter command:  <[exit | [begin | begin2pc | commit | rollback] | [n <number>] | <[i(nsert) | g(et) | u(pdate) | (u)p(sert) | d(elete)]> <key> [<value>]");
                        System.out.print("> ");
                        try {
                            InputStreamReader converter = new InputStreamReader(System.in);
                            BufferedReader in = new BufferedReader(converter);
                            String input = in.readLine();
    
                            if (input == null || input.trim().length() == 0)
                                continue;
    
                            if (input.toLowerCase().startsWith("exit")) {
                                System.out.println("Exiting...");
                                System.exit(0);
                                return;
                            }
    
                            // grab info from the user input and create an object for key and value
                            // these objects canl be stored inside the grid when an operation is performed
                            StringTokenizer st = new StringTokenizer(input, " ");
                            String cmd = st.nextToken();
                            TestKey k = null;
                            TestValue v = null;
                            if(st.hasMoreTokens()) {
                            	if (cmd.equals("n")) {
                            		String n = st.nextToken();
                            		// for inserting multiple objects command
                            		runCommandManualTx(mapName, sess, cmd, n, null);
                            	}
                            	else {
                            		k = new TestKey(st.nextToken());
                            		if (st.hasMoreTokens()) {
                            			v = new TestValue(st.nextToken());
                            		}
                            		// for commands with key values
                            		runCommandManualTx(mapName, sess, cmd, k, v);
                            	}
                            }
                            else {
                            	// for just commands
                        		runCommandManualTx(mapName, sess, cmd, k, v);
                        	}
                            
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } finally {
                    // Clean-up and close the session.
                    try {
                        if(sess.isTransactionActive()) {
                            try {
                                if(sess.isMarkedRollbackOnly()) {
                                    sess.rollback();
                                } else {
                                    sess.commit();
                                }
                            } catch (Exception e) {
                                // Just log the exception
                                e.printStackTrace();
                            }
                        }
                    } finally {
                        sess.close();
                        sess = null;
                    }
                }
            }   
        } finally {        
            // Disconnect from the grid.
            grid.destroy();
            grid = null;
        }
    }

    /**
     * Run a single map operation using an automatic transaction.  In this mode, each operation is
     * performed in a single transaction, where the transaction is not manually demarcated.
     * @param command the map operation to run.
     * @param k the key
     * @param v the value
     * @throws ObjectGridException thrown if there is an error.
     */
    public void runCommandAutoTx(String mapName, String command, Object k, Object v) throws ObjectGridException {
        Session sess = grid.getSession();
        try {
            // Get the ObjectMap
            ObjectMap map1 = sess.getMap(mapName);

            // Invoke the CRUD operation using automatic transactions.
            if (command.equals("i")) {
                map1.insert(k, v);
                System.out.println("SUCCESS: Inserted " + v + " with key " + k);
            } else if (command.equals("p")) {
                    map1.upsert(k, v);
                    System.out.println("SUCCESS: Put " + v + " with key " + k);
            } else if (command.equals("u")) {
                map1.update(k, v);
                System.out.println("SUCCESS: Updated key " + k + " with value " + v);
            } else if (command.equals("d")) {
                map1.remove(k);
                System.out.println("SUCCESS: Deleted value with key " + k);
            } else if (command.equals("g")) {
                Object value = (Object) map1.get(k);
                if (value != null)
                    System.out.println("Value is " + value);
                else
                    System.out.println("Not found"); 
        	} else if (command.equals("n")) {
        		Integer count = 0;
        		Integer length = Integer.parseInt(k.toString());
        		for (int i=0; i < length; i++) {
        			map1.insert(new TestKey(count.toString()), new TestValue(count.toString()));
        			count++;
        		}
            	System.out.println("SUCCESS: Inserted " + length + " keys and values");
        	}
            else {
                System.out.println("Unknown operation: " + command);
                printUsage();
            }
        } finally {
            // Close the session.
            sess.close();
        }
    }
    
    /**
     * Run a single map operation using a manual transaction.  In this mode, you must have a 
     * current session available to perform a transaction.
     * @param sess the map session
     * @param command the map operation to run.
     * @param k the key
     * @param v the value
     * @throws ObjectGridException thrown if there is an error.
     */
    public void runCommandManualTx(String mapName, Session sess, String command, Object k, Object v) throws ObjectGridException {
        // Get the ObjectMap from the Session.
        // The ObjectMap is cached in the Session.
        ObjectMap map1 = sess.getMap(mapName);
        
        // Retrieve the partition id that the request will route to, for logging...
        // The PartitionManager is also useful for batching up multiple operations in 
        // a single partition transaction.
        int partitionId = k == null ? -1 : grid.getMap(mapName).getPartitionManager().getPartition(k);

        // Invoke the CRUD operation using automatic transactions.
        if (command.equals("i")) {
            map1.insert(k, v);
            System.out.println("SUCCESS: Inserted " + v + " with key " + k + ", partitionId=" + partitionId);
        } else if (command.equals("p")) {
        	map1.upsert(k, v);
        	System.out.println("SUCCESS: Put " + v + " with key " + k + ", partitionId=" + partitionId);
        } else if (command.equals("u")) {
            map1.update(k, v);
            System.out.println("SUCCESS: Updated key " + k + " with value " + v + ", partitionId=" + partitionId);
        } else if (command.equals("d")) {
            map1.remove(k);
            System.out.println("SUCCESS: Deleted value with key " + k + ", partitionId=" + partitionId);
        } else if (command.equals("g")) {
            Object value = (Object) map1.get(k);
            if (value != null)
                System.out.println("Value is " + value + ", partitionId=" + partitionId);
            else
                System.out.println("Not found");
        } else if (command.equals("begin")) {
            sess.setTxCommitProtocol(TxCommitProtocol.ONEPHASE);
            sess.begin();
            System.out.println("SUCCESS: Transaction started.");
        } else if (command.equals("begin2pc")) {
            sess.setTxCommitProtocol(TxCommitProtocol.TWOPHASE);
            sess.begin();
            System.out.println("SUCCESS: 2-Phase capable, multi-partition transaction started.");
        } else if (command.equals("commit")) {
            sess.commit();
            System.out.println("SUCCESS: Transaction committed.");
        } else if (command.equals("rollback")) {
            sess.rollback();
            System.out.println("SUCCESS: Transaction rolled-back.");
        } else if (command.equals("n")) {
        	Integer count = 0;
        	Integer length = Integer.parseInt(k.toString());
        	for (int i=0; i < length; i++) {
        		map1.insert(new TestKey(count.toString()), new TestValue(count.toString()));
        		count++;
        	}
            System.out.println("SUCCESS: Inserted " + length + " keys and values, partitionId=" + partitionId);
        } else {
            System.out.println("Unknown operation: " + command);
            printUsage();
        }
    }
    
    private static void printUsage() {
        System.out.println("This program executes simple CRUD operations on a map.  This can be run interactively wihtout parameters, or using the command-line.");
        System.out.println();
        System.out.println("script usage: runclient.sh/runclient.bat <[i(nsert) | u(pdate) | (u)p(sert) | d(elete) | g(et)]> <key> [<value>] | [n <number>]");
        System.out.println("java usage: java <jvm args> Client <catalog endpoint hostname:port> <[i(nsert) | u(pdate) | (u)p(sert) | d(elete) | g(et)]> <key> [<value>] | [n <number>]");
        System.out.println();
        System.out.println("\ti: insert the key and value");
        System.out.println("\tu: update the value of the specified key");
        System.out.println("\tu: puts the key and value using upsert");
        System.out.println("\td: delete the key");
        System.out.println("\tg: retrieve and display the value of the specified key");
        System.out.println("\tn: insert n objects into the map");
    }
}
